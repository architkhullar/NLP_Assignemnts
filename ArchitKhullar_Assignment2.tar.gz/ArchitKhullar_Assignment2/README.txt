The program has been run on a Linux environemnt woth python3
you can run the file using python3 ArchitKhullar_Assignment2.py

The only python file i.e. ArchitKhullar_Assignment2.py contains the code for both the questions.

There are 4 other text files namely:

EnglishVSEnglishOutput.txt
EnglishVSFrenchOutput.txt
SpanishVSSpanishOutput.txt
SpanishVSItalianOutput.txt

As the name suggests, these contain individual accuracyoutputs for each of the unigram/ bigram/ trigram models along with probability of each word. 

It might be difficult to look for the individual accuracies for each model in each of these files. Hence, there is another text file with the name:

Summary.txt

which contains:
1. the Final sumaarized output of the Accuracies
2. The way I have apprached the problem
3. Observation or answer to question 2 of this Assignememt



							-------Thanks--------
